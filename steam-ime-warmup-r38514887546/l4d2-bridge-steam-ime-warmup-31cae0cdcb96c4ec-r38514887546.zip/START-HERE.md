# Steam Overlay IME 一次性初始化实验桥

Windows 原生 Presenter/IME/capture 回归及 x86 Client、x64 Host、x86 Host 编译通过。
独立实机模式11已证明隐藏 EDIT 短暂聚焦并销毁后原窗口恢复中文；真实 Steam 仍待验证。
本包仅含配套桥更新；沿用现有 DXVK、ReShade、L4N，不是正式 Release。

1. 完全关闭游戏和 Host，备份当前三个桥文件及 bridge.conf。
2. 将本包 bin/ 下三个配套二进制覆盖到游戏对应位置，不要新旧混用。
3. 保留实际 bin/.l4d2bridge/bridge.conf 中正常工作的 Steam/Presenter 配置。
   合入 config/STEAM-IME-NATIVE-WARMUP.conf 的全部设置，替换同名项；不要直接覆盖整个配置。
4. 重启游戏，正常游戏中 Shift+Tab 打开 Overlay，在聊天框用输入法输入中文。
   测试候选框、提交汉字、关闭/重开 Overlay、中英切换、Alt+Tab 后返回和邀请界面。
5. 发送 bridge32.log 和 bridge64.log，并注明输入结果。首轮会有 event=native-warmup，
   created/focused/restored/destroyed 应均为1。每个 Presenter 窗口只尝试一次。

对照：关闭游戏，将 server.steamImeNativeWarmup 改为 False，重启同一匹配包。
回滚：关闭游戏，完整恢复备份的三个旧桥文件及旧配置，再重启。
故障不循环重试，不强制中文模式；初始化不创建常驻 EDIT、额外线程或提交队列。
Steam Renderer hash mismatch 的邀请/网页代理版本校验问题属于独立事项，本包没有放宽校验。
main、VERSION、Tag 和正式 Release 未修改。详情见 docs/STEAM-IME-NATIVE-WARMUP.md。
