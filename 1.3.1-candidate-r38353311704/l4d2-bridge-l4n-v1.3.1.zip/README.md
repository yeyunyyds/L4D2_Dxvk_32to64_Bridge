# Optional L4N Bridge controls 1.3.1

Close L4D2 and merge bin/neko/plugins into the game directory. Bridge works without this plugin. Requires L4N SDK v2 HUD support. See [menu and installation](docs/L4N-BRIDGE-CONTROLS.md).
