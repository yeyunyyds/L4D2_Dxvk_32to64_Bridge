# IME 独立窗口对照 + Bridge 早期 Hook 诊断

原生编译及自动测试通过；真实中文组合输入尚待验证。这是调查包，未宣称修复。

先关闭游戏，解压全部文件，运行 IME-Probe/Start-Probe.cmd。
先测按钮 1、4：在 Custom 中切中文输入拼音，观察候选框和汉字。
可点击 Use fresh HIMC 再测，随后 Restore original HIMC。
再点击 Add Native EDIT，测试它，并回到 Custom 再试。
若 1/4 有差异，再测 2/3/5/6。不要用粘贴替代输入法测试。
发送 IME-Probe/logs 文件夹，并注明各项结果。

如继续收集游戏内早期 Hook：备份并替换 bridge-update/bin 下全部三个对应二进制。
保留现有正常工作的 Steam/Presenter 配置，合入 bridge-update/config/STEAM-IME-EARLY-HOOK.conf，同名项替换。
完全退出游戏和 Host 后重启，试一次 Overlay 中文输入，发送 bridge32.log/bridge64.log。
默认运行时未新增窗口、低级键盘 Hook 或线程。独立工具只操作自己创建的进程和窗口。
main、VERSION、正式 Release 未修改；原来的匹配包可完整回滚。
