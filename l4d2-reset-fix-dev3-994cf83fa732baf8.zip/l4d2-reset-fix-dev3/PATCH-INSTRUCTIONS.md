# Reset 黑屏修复候选包

本包 build ID：`l4d2-1.1.2-dev.3+994cf83fa732baf8`。它与此前 dev.3 ZIP 不同，是本次 Reset 修复的本地候选构建；尚未完成原生 L4D2 验证。

完全退出游戏和 Host 后，备份并用本包的 bin 合并覆盖游戏 bin，同时替换以下三件套：

- bin/dxvk_d3d9.dll
- bin/.l4d2bridge/L4D2Bridge32.exe
- bin/.l4d2bridge/L4D2Bridge64.exe

保留现有配置、DXVK/mem1、ReShade、retention DB 和 L4N 插件；这个包的 bin 仅包含三件套。继续从 Steam 使用原来的启动方式。

先在主菜单重复窗口→全屏→窗口，确认返回窗口有画面，然后正常退出。保存该轮 bridge32.log、bridge-host32.log 和 L4D2Bridge32_d3d9.log。x64 Host 模式用对应 bridge64.log / L4D2Bridge64_d3d9.log。详细依据与验证边界见 docs/FULLSCREEN-WINDOW-RESET.md。
