# L4N Bridge 插件 common-settings-2

仅更新插件，不替换 Bridge Client、Host、后端或配置。兼容上一轮 ZIP 分支提供的 L4N 常用设置版本（Bridge build ID l4d2-1.2.0-dev.1+9517b390541102e1）。需要支持 SDK v2 HUD 的 L4N。退出游戏后，将 bin/neko/plugins/L4D2BridgePlugin.dll 覆盖到游戏相同路径。

- Status 只显示 PageBlock，不显示 Host、Presenter 或重启状态。
- Memory Policy 首行显示当前策略: keep/lg/drop。runtime 与 configure 相同显示 configure；不同显示 runtime。keep、lg、drop [experimental] 仅改变当前运行策略。最下面 save to configure 才将实时 runtime 策略交给 Client 保存。
- Host 只显示 Configured Host，选择 x86/x64 不写文件，底部 Save 才保存；保存结果重新读取配置显示，下次完整重启生效。
- GC 和 ReShade Presenter 行为保持原样。插件不直接读写 bridge.conf。旧 Bridge 保留 Stats/GC/运行策略，保存及 Host/Presenter 不可用。

L4N SDK v2 操作回调打开结果页；选择结果页底部可直接保存。HUD 已打开的父页面是缓存，退回后重新进入菜单可刷新当前值。

Windows 原生 MSVC x86 构建、modern/legacy/missing 三种回调测试与其余 CI 检查通过。仍需真实 L4D2 + L4N 验证 HUD 中文字体、布局和导航。
