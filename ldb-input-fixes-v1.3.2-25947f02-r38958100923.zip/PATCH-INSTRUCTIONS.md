# 1.3.2

Read [release instructions](docs/RELEASE-V1.3.2.md), [configuration reference](docs/CONFIGURATION.md) and [optional L4N settings](docs/L4N-BRIDGE-CONTROLS.md). Replace all three matched Bridge binaries. The patch preserves runtime configuration/backends. The full package includes default configuration and DXVK. L4N plugin is optional. Do not run Install-ColorDiagnostics.ps1 for a normal update: it actively enables colour diagnostics.
