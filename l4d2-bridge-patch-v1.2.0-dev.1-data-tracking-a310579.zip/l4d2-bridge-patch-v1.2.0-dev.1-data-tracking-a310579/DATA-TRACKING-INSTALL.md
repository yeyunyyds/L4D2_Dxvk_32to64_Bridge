# 1.2.0-dev.1 数据/资源追踪实验

源码 commit a31057925e1bec27a28bf35c445a8dfe25095801，构建标识 l4d2-1.2.0-dev.1+ca739d2c9490facf。Windows 原生 x86 Client、x86/x64 Host 编译与 17 项 Test/Load 检查通过。未改动 L4N 插件，本包不包含或重建插件/DXVK/ReShade。

完整退出 L4D2 和 Host 后，将 bin 内匹配三个文件覆盖到游戏相同相对路径，保留已有 bin/.l4d2bridge/bridge.conf、DXVK、ReShade 和 L4N 插件。首次安装应先使用已有完整包，再覆盖此 patch。

要采集证据，合并 config/DATA-TRACKING.conf 中四个 key 到已有 bridge.conf，完整重启：client.dataDiagnostics=True、server.dataDiagnostics=True，两侧 dataSnapshotMs=5000。不要用配置片段覆盖整个配置文件；Bridge 默认不启用追踪。

一次完整运行建议：主菜单→本地进图→正常游戏→联机→过图→正常退出。Client 日志在游戏 EXE 同目录 l4d2-data-client.log，Host 日志在 Host EXE 同目录（通常 bin/.l4d2bridge）l4d2-data-host.log。保留这一轮已有 memory/host-memory/PageBlock 与 Bridge 主日志，一起提供；下次启动会覆盖该轮追踪日志。

python scripts/analyze_data_diagnostics.py l4d2-data-client.log l4d2-data-host.log --json data-report.json

诊断有计数、后台线程和写盘开销；正常使用时把两侧 dataDiagnostics 改回 False 并完整重启。此版用于选下一版本优化目标，保留现有回收/恢复/渲染语义。详见 docs/DATA-TRACKING.md。
