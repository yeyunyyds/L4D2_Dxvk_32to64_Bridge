# PageBlock experiment

Read [setup, coverage and validation](docs/PAGEBLOCK-RESIDENCY-EXPERIMENT.md) and [Drop/GC controls](docs/PAGEBLOCK-DROP-GC.md).
