# 联机蓝绿偏色：一次运行诊断包

Build ID: `l4d2-1.1.2-dev.3+b39cbd5e1a902ace`

这是用户同意的诊断版本，保留原始纹理创建 HRESULT，没有小 DXT fallback 或 state replay。保留已通过实机的 Reset 第二版。此新包尚未进行偏色实机复测。

完全退出游戏和 Host，在解压目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\Install-ColorDiagnostics.ps1 -GameDirectory "你的 Left 4 Dead 2 安装目录"
```

脚本验证包内三个二进制的 SHA256，备份旧三件套和配置，安装新三件套并开启四项诊断设置。保留当前 Host 位数、backend、ReShade、Mod、插件和 retention DB。

一次运行：本地单人确认画面 → 返回菜单 → 进入服务器 → 正常退出。上传游戏根目录 l4d2-color-client.log、bin/.l4d2bridge/l4d2-color-host.log 及同次 Client/Host/backend 普通日志，回答一句“服务器蓝绿色仍存在／已消失”。无需 marker 或 A/B 切换。

详细记录、限制、回退和源码说明：[docs/NETWORK-COLOR-DIAGNOSTICS.md](docs/NETWORK-COLOR-DIAGNOSTICS.md)。
