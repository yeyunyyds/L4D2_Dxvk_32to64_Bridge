# v1.2.0 Diagnostics Separation — 实验开发构建

本包基于 v1.2.0 的诊断/观测分离源码，不是正式 Release 更新。运行时源码来自
`4b07438271eaa3292c1dbfd957749cc88230316b`；build ID 为
`l4d2-1.2.0+8ce8005da14ea40a`。保留基础版本 1.2.0，使用实验名称及 build ID 区分。

Windows CI 编译与测试通过：
https://github.com/yeyunyyds/L4D2_Dxvk_32to64_Bridge/actions/runs/38007197537

## 安装

完全退出 L4D2 和 Bridge Host，备份现有安装，再把本包 bin 合并到游戏目录。
必须同时替换 dxvk_d3d9.dll、L4D2Bridge32.exe、L4D2Bridge64.exe；不要混用构建。

- 完整包包含三个桥二进制、x86/x64 DXVK 2.6.1 和新默认运行配置，适合首次安装。
  合并时会覆盖同路径的后端和 bridge.conf。已有定制配置请优先使用更新包。
- 更新包只提供三个桥二进制，保留已安装后端、ReShade、运行配置和 retention DB。
  根目录 config/bridge.conf 只是参考，不会自动应用。
- L4N 插件未修改、不包含在本包中；已有插件继续使用。

## 关闭内存观测和 crash history

完整包已明确配置以下默认值。更新包保留旧配置，请检查游戏
bin/.l4d2bridge/bridge.conf，将已有定义更新或补充，避免产生重复 key：

```ini
client.memoryMonitoring = False
server.memoryMonitoring = False
client.crashDiagnostics = False
server.crashDiagnostics = False
```

memoryMonitoring=False 不进行周期 VA/进程/GPU 观察，也不被手动 GC 强制绕过。
crashDiagnostics=False 不维护健康运行时 API/command history，基础故障报告仍保留。
新 crashDiagnostics 缺失且旧 exceptionDiagnosticsDetailed=True 时，为兼容旧配置仍开启 history，
因此测试全关时应明确写 False。独立 data/color/API wait/PageBlock/Steam 诊断继续按各自开关控制。
保留自己明确需要的 Presenter/Input 配置，不必用完整包默认值覆盖定制设置。

不要运行 Install-ColorDiagnostics.ps1 作为普通安装步骤，它会主动开启偏色诊断。
配置改动后完整重启游戏；旧诊断文件不会被删除，检查是否新增或更新时间变化。

## 本轮诊断状态 / 失败隔离

API wait 统计表、crash TLS history、Data 每资源 metadata 按启用需求创建。
VB/IB 分配由 Core 持有；内存诊断只观察分配/释放。
retention 诊断日志创建、写入或回调失败不再触发 LG fallback KEEP。
KEEP DB、真实资源分配或 recovery 的 Core 失败规则继续保留。
关闭所有可选诊断时的 LG 驱逐、恢复、KEEP 提升和持久 DB 命中已通过自动测试。
同时验证了诊断分配/线程初始化失败、并发回调失效及 TLS 退出边界。

## 实机日志对应修正

Client 不再以线程方式安装 global-only WH_KEYBOARD_LL；保留三个有效线程 hook 和
Host Presenter 原有的前台窗口过滤键盘 hook。真正安装失败记录即时 Win32 error。
DirectInput 旧版成功请求只在 Debug 日志开启时显示原始版本，实际失败记录 HRESULT；
调用参数和结果保持不变。Query AddRef/Release 移除遗留 missing-call 错误标记，
引用与销毁流程不变。L4N 未修改，无需更新或重新安装插件。

复测 ReShade 面板/快捷键、面板关闭后键鼠、切窗/全屏、切到其他程序后返回游戏。
这三项修正不代表已全面验证旧 DirectInput 接口。Host SurfaceQueries 累计统计仍是
已知后续诊断分离项，本包没有修改 Getter/身份校验/引用释放或这些计数。

## 验证范围

所有原生回归已通过，包括未改动的 Volume x86/x64 各 59 项测试。
仍需 L4D2 实机验证两种 Host、本地/联机/过图、切窗/Reset、策略和 GC/恢复，
以及需要时的 Presenter/ReShade 输入。没有 FPS 提升结论。
默认策略仍是 learned-aggressive；本包未引入优化算法、改变 IPC/Reset/资源语义。

完整分类与结果见 docs/RUNTIME-DIAGNOSTICS-AUDIT.md、
docs/RUNTIME-DIAGNOSTICS-SEPARATION.md 和 docs/CONFIGURATION.md。
