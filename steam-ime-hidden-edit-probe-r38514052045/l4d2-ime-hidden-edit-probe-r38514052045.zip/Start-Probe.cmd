@echo off
cd /d "%~dp0"
ImeWindowProbe32.exe
