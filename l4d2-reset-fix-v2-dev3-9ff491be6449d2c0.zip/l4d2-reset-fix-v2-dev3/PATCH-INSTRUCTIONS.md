# Reset 黑屏修复第二版候选包

Build ID：`l4d2-1.1.2-dev.3+9ff491be6449d2c0`。首版候选 `994cf83fa732baf8` 已实机确认首次 Reset 回归，本包修正遗漏的运行时查询引用；仍须原生 L4D2 复测。

完全退出游戏和 Host 后，备份并用本包 bin 合并覆盖游戏 bin，同时替换三件套：

- bin/dxvk_d3d9.dll
- bin/.l4d2bridge/L4D2Bridge32.exe
- bin/.l4d2bridge/L4D2Bridge64.exe

保留现有配置、DXVK/mem1、ReShade、retention DB 与 L4N 插件；本包 bin 仅包含匹配的三件套。继续从 Steam 使用原来的启动方式。

先在主菜单重测窗口→全屏→窗口，确认两次切换都有画面，再正常退出。保存同轮 bridge32.log、bridge-host32.log 和 L4D2Bridge32_d3d9.log。x64 Host 模式使用对应 bridge64.log / L4D2Bridge64_d3d9.log。详细排查与验证边界见 docs/FULLSCREEN-WINDOW-RESET.md。
