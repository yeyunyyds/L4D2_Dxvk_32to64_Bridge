# 1.2.0-dev.1 VB/IB 契约与只读诊断版

源码 3a92f3e4f5b9e868d2ef44402aaf5c8b6f11bf8b，构建标识 l4d2-1.2.0-dev.1+b5a6e83f77e1549f。Windows 原生 x86 Client、x86/x64 Host 编译及 18 项 Test/Load 检查通过。L4N 未改动、未重新编译或打包。本包不包含 DXVK/ReShade 本体，不覆盖已有运行配置。

本轮保留 FULL_SHADOW，不启用 RANGE_STAGING，实际避免的持久 shadow 字节为 0。WRITEONLY 不保证每次 Lock 写满，范围暂存不能丢失 Lock 内未修改的历史字节。新增 BUFFER、DYNAMIC_LOCK、STATE 均为只读测量，不过滤 API 或改动上传语义。

完整退出 L4D2 和 Host，按相对路径覆盖 bin 中的三个匹配文件。保留已有 bin/.l4d2bridge/bridge.conf、DXVK、ReShade 和 L4N。首次安装先使用已有完整包，再覆盖此 patch。

正常使用默认关闭诊断。需要采集时，将 config/DATA-TRACKING.conf 中四个 key 合并进已有 bridge.conf，完整重启；不要用配置片段覆盖整个文件。开启比较、计数和写盘会有开销。

采集建议：主菜单→本地进图→正常游戏→联机→过图→正常退出。提供本次 l4d2-data-client.log、l4d2-data-host.log，以及原有 memory/host-memory/PageBlock/Bridge 日志。Client data 日志位于游戏 EXE 同目录，Host data 日志位于 Host EXE 同目录；下次启动会覆盖同侧追踪日志。

python scripts/analyze_data_diagnostics.py l4d2-data-client.log l4d2-data-host.log --json data-report.json

candidate 是待分析的静态 WRITEONLY 容量，不是可安全回收量。重点观察静态/动态 shadow 占用、同值比例和锁大小分布。详见 docs/BUFFER-SHADOW-CONTRACT.md。
