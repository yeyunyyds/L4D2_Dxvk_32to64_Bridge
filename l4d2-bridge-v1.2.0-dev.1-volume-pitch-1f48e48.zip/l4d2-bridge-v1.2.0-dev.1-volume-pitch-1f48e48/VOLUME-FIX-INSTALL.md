# Volume 字节 pitch 修复：1.2.0-dev.1 开发分支

源码 commit 1f48e48，匹配 Bridge build ID l4d2-1.2.0-dev.1+14a3039fb72bcf95。Windows 原生 x86 Client、x86/x64 Host、x86 L4N 编译通过，16 项 Test/Load CI 步骤通过，包含两种位数的 Volume 59 用例。修复不在旧 v1.2.0-dev.1 Release 附件中。

完全退出游戏和 Host 后更新匹配三件套。已有安装使用 patch 包：将 bin 内三个 Bridge 文件复制到游戏相同相对路径；保留运行配置、DXVK 后端（包括用户自选 DXVK 3.1）、ReShade 与 retention DB。首次安装才使用完整包；默认 x86 Host 和项目固定 DXVK 2.6.1。

32×32×1 X8R8G8B8 Volume 的 API RowPitch/SlicePitch 改为128/4096，UnlockBox 按字节行/层间距上传；传输协议和 Host 复制算法不变。无须开启诊断，无新增游戏私有行为。偏色是否改善仍需同次本地→服务器画面对比。详细说明见 docs/VOLUME-PITCH-FIX.md。

optional/L4N/L4D2BridgePlugin.dll 为可选 common-settings-2，复制到 bin/neko/plugins/；Bridge 本体不依赖插件，已有该版插件可继续使用。Status 仅看 PageBlock；Memory Policy 的 keep/lg/drop 仅改 runtime，save to configure 才保存；Host 选择后 Save，完整重启生效；Presenter 保存后重启生效。

普通更新无需运行 Install-ColorDiagnostics.ps1；只有需要复现取证时主动开启四项偏色诊断，参考 docs/NETWORK-COLOR-DIAGNOSTICS.md。诊断默认关闭。未来 GitHub Release 的插件单独 ZIP，当前 ZIP 下载分支允许 optional 插件。
