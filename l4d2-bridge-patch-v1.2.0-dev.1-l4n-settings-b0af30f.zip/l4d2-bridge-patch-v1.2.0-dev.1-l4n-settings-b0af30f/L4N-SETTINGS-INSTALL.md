# L4N 常用设置实验构建

当前分支 b0af30f，Windows 原生编译与 CI 通过。

关闭游戏与 Host 后更新。已有安装推荐升级补丁，只替换三个匹配 Bridge 二进制，保留配置、后端、ReShade 和 retention DB。首次安装使用完整包，默认 x86 Host。

可选 L4N 插件在 optional/L4N/L4D2BridgePlugin.dll，需要手动复制到游戏 bin/neko/plugins/；Bridge 不依赖插件。菜单顺序：Status、GC、Memory Policy、ReShade Presenter、Host。Memory Policy 即时生效并保存；Host/Presenter 保存后完整重启生效。不要为普通安装运行偏色诊断安装脚本。

本 ZIP 属于下载分支，允许携带可选插件。以后 GitHub Release 的插件将单独提供 ZIP，不放入本体或 patch。详细说明见 docs/L4N-BRIDGE-CONTROLS.md。
